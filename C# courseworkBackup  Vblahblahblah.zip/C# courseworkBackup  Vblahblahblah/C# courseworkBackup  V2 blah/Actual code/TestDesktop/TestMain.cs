using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System;
using Transparent_Form;

namespace Transparent_Form_UnitTests
{
    [TestClass]
    public class MainFormTests
    {
        [TestMethod]
        public void TestShowSubmenu()
        {
            // Arrange
            var mainForm = new MainForm();

            // Act
            mainForm.button_std_Click(null, null); // Simulate clicking on the database button

            // Assert
            Assert.IsTrue(mainForm.panel_stdsubmenu.Visible); // Check if the submenu panel is visible after clicking
            Assert.IsTrue(mainForm.button_registration.Visible); // Check if the registration button is visible after clicking
            Assert.IsTrue(mainForm.button_manage.Visible); // Check if the manage button is visible after clicking
        }

        [TestMethod]
        public void TestHideSubmenu()
        {
            // Arrange
            var mainForm = new MainForm();
            mainForm.button_std_Click(null, null); // Simulate clicking on the database button

            // Act
            mainForm.HideSubmenu(); // Simulate hiding the submenu

            // Assert
            Assert.IsFalse(mainForm.panel_stdsubmenu.Visible); // Check if the submenu panel is hidden
            Assert.IsFalse(mainForm.button_registration.Visible); // Check if the registration button is hidden
            Assert.IsFalse(mainForm.button_manage.Visible); // Check if the manage button is hidden
        }

        [TestMethod]
        public void TestClickRegistrationButton()
        {
            // Arrange
            var mainForm = new MainForm();
            mainForm.button_std_Click(null, null); // Show the submenu
            mainForm.ShowSubmenu(mainForm.panel_stdsubmenu); // Ensure submenu is visible
            var registrationForm = new MockRegistrationForm(); // Mock registration form

            // Act
            mainForm.button_registration_Click(null, null); // Simulate clicking on the registration button

            // Assert
            Assert.AreEqual(registrationForm, mainForm.ActiveForm); // Check if the registration form is set as active form
            Assert.IsTrue(mainForm.panel_main.Controls.Contains(registrationForm)); // Check if the registration form is added to the panel_main
            Assert.IsTrue(registrationForm.Visible); // Check if the registration form is visible
        }

        [TestMethod]
        public void TestClickManageButton()
        {
            // Arrange
            var mainForm = new MainForm();
            mainForm.button_std_Click(null, null); // Show the submenu
            mainForm.ShowSubmenu(mainForm.panel_stdsubmenu); // Ensure submenu is visible
            var manageForm = new MockManageForm(); // Mock manage form

            // Act
            mainForm.button_manage_Click(null, null); // Simulate clicking on the manage button

            // Assert
            Assert.AreEqual(manageForm, mainForm.ActiveForm); // Check if the manage form is set as active form
            Assert.IsTrue(mainForm.panel_main.Controls.Contains(manageForm)); // Check if the manage form is added to the panel_main
            Assert.IsTrue(manageForm.Visible); // Check if the manage form is visible
        }
    }
} 
