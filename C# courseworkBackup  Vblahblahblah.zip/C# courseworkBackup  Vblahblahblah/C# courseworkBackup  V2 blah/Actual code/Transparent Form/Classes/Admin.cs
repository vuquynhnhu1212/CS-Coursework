﻿using System;

namespace Transparent_Form.Classes
{
    // Derived class representing an administrator
    public class Admin : Person
    {
        // Properties specific to administrators
        public decimal Salary { get; set; }
        public string WorkType { get; set; }
        public string WorkingHours { get; set; }

        // Constructor
        public Admin(int userID, string name, string telephone, string email, string role, DateTime birthday, byte[] picture, decimal salary, string workType, string workingHours)
            : base(userID, name, telephone, email, role, birthday,picture)
        {
            Salary = salary;
            WorkType = workType;
            WorkingHours = workingHours;
        }

        // Override method to display admin information
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Salary: {Salary:C}");
            Console.WriteLine($"Work Type: {WorkType}");
            Console.WriteLine($"Working Hours: {WorkingHours}");
        }
    }
}
