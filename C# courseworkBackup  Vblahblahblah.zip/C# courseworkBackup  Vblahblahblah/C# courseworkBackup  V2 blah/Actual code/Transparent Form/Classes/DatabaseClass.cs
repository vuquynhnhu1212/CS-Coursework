﻿using System;
using System.Data;
using MySql.Data.MySqlClient;

namespace Transparent_Form.Classes
{
    internal class DatabaseClass
    {
        DBconnect connect = new DBconnect();

        // Insert user data into the database
        public int InsertUser(Person person)
        {
            int userId = 0;
            connect.openConnect();
            MySqlCommand command = connect.getconnection.CreateCommand();
            MySqlTransaction transaction = connect.getconnection.BeginTransaction();
            command.Connection = connect.getconnection;
            command.Transaction = transaction;

            try
            {
                // Insert into user table
                command.CommandText = "INSERT INTO `user`(`Name`, `Phone`, `Email`, `Role`, `Birthday`, `Picture`) VALUES (@Name, @telephone, @email, @role, @birthday, @picture)";
                command.Parameters.AddWithValue("@Name", person.Name);
                command.Parameters.AddWithValue("@telephone", person.Telephone);
                command.Parameters.AddWithValue("@email", person.Email);
                command.Parameters.AddWithValue("@role", person.Role);
                command.Parameters.AddWithValue("@birthday", person.Birthday);
                command.Parameters.AddWithValue("@picture", person.Picture);
                command.ExecuteNonQuery();

                // Retrieve the generated UserID
                command.CommandText = "SELECT LAST_INSERT_ID()";
                userId = Convert.ToInt32(command.ExecuteScalar());

                transaction.Commit();
            }
            finally
            {
                connect.closeConnect();
            }

            return userId;
        }

        // Get all users from the database
        public DataTable GetUserList()
        {
            MySqlCommand command = new MySqlCommand("SELECT * FROM `user`", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        // Get all teachers from the database
        public DataTable GetTeacherList()
        {
            MySqlCommand command = new MySqlCommand("SELECT t.*, u.Name FROM teacher t JOIN user u ON t.UserID = u.UserID", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        // Get all admins from the database
        public DataTable GetAdminList()
        {
            MySqlCommand command = new MySqlCommand("SELECT a.*, u.Name FROM admin a JOIN user u ON a.UserID = u.UserID", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        // Get all users from the database
        public DataTable GetStudentList()
        {
            MySqlCommand command = new MySqlCommand("SELECT s.*, u.Name FROM student s JOIN user u ON s.UserID = u.UserID", connect.getconnection);
            MySqlDataAdapter adapter = new MySqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            return table;
        }

        // Insert teacher into the database
        public bool InsertTeacher(Teacher teacher)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `teacher`(`UserID`, `Salary`, `Subject1`, `Subject2`) VALUES (@userId, @salary, @subject1, @subject2)",
                                                     connect.getconnection);
            command.Parameters.AddWithValue("@userId", teacher.UserID);
            command.Parameters.AddWithValue("@salary", teacher.Salary);
            command.Parameters.AddWithValue("@subject1", teacher.Subject1);
            command.Parameters.AddWithValue("@subject2", teacher.Subject2);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Insert admin into the database
        public bool InsertAdmin(Admin admin)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `admin`(`UserID`, `Salary`, `WorkType`, `WorkingHours`) VALUES (@userId, @salary, @workType, @workingHours)",
                                                     connect.getconnection);
            command.Parameters.AddWithValue("@userId", admin.UserID);
            command.Parameters.AddWithValue("@salary", admin.Salary);
            command.Parameters.AddWithValue("@workType", admin.WorkType);
            command.Parameters.AddWithValue("@workingHours", admin.WorkingHours);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Insert student into the database
        public bool InsertStudent(Student student)
        {
            MySqlCommand command = new MySqlCommand("INSERT INTO `student`(`UserID`, `CurrentSubject1`, `CurrentSubject2`, `PreviousSubject1`, `PreviousSubject2`) VALUES (@userId, @currentSubject1, @currentSubject2, @previousSubject1, @previousSubject2)",
                                                     connect.getconnection);
            command.Parameters.AddWithValue("@userId", student.UserID);
            command.Parameters.AddWithValue("@currentSubject1", student.CurrentSubject1);
            command.Parameters.AddWithValue("@currentSubject2", student.CurrentSubject2);
            command.Parameters.AddWithValue("@previousSubject1", student.PreviousSubject1);
            command.Parameters.AddWithValue("@previousSubject2", student.PreviousSubject2);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Update teacher data in the database
        public bool UpdateTeacherData(Teacher teacher)
        {
            MySqlCommand command = new MySqlCommand("UPDATE `teacher` SET `Salary` = @salary, `Subject1` = @subject1, `Subject2` = @subject2 WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", teacher.UserID);
            command.Parameters.AddWithValue("@salary", teacher.Salary);
            command.Parameters.AddWithValue("@subject1", teacher.Subject1);
            command.Parameters.AddWithValue("@subject2", teacher.Subject2);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Update admin data in the database
        public bool UpdateAdminData(Admin admin)
        {
            MySqlCommand command = new MySqlCommand("UPDATE `admin` SET `Salary` = @salary, `WorkType` = @workType, `WorkingHours` = @workingHours WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", admin.UserID);
            command.Parameters.AddWithValue("@salary", admin.Salary);
            command.Parameters.AddWithValue("@workType", admin.WorkType);
            command.Parameters.AddWithValue("@workingHours", admin.WorkingHours);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Update student data in the database
        public bool UpdateStudentData(Student student)
        {
            MySqlCommand command = new MySqlCommand("UPDATE `student` SET `CurrentSubject1` = @currentSubject1, `CurrentSubject2` = @currentSubject2, `PreviousSubject1` = @previousSubject1, `PreviousSubject2` = @previousSubject2 WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", student.UserID);
            command.Parameters.AddWithValue("@currentSubject1", student.CurrentSubject1);
            command.Parameters.AddWithValue("@currentSubject2", student.CurrentSubject2);
            command.Parameters.AddWithValue("@previousSubject1", student.PreviousSubject1);
            command.Parameters.AddWithValue("@previousSubject2", student.PreviousSubject2);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Update user data in the database
        public bool UpdateUser(Person person)
        {
            MySqlCommand command = new MySqlCommand("UPDATE `user` SET `Name` = @Name, `Phone` = @telephone, `Email` = @email, `Role` = @role, `Birthday` = @birthday, `Picture` = @picture WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", person.UserID);
            command.Parameters.AddWithValue("@Name", person.Name);
            command.Parameters.AddWithValue("@telephone", person.Telephone);
            command.Parameters.AddWithValue("@email", person.Email);
            command.Parameters.AddWithValue("@role", person.Role);
            command.Parameters.AddWithValue("@birthday", person.Birthday);
            command.Parameters.AddWithValue("@picture", person.Picture);

            connect.openConnect();
            bool success = command.ExecuteNonQuery() == 1;
            connect.closeConnect();

            return success;
        }

        // Delete user from the database
        // Delete user and related records from the database
        public bool DeleteUser(int userId)
        {
            connect.openConnect();
            MySqlTransaction transaction = connect.getconnection.BeginTransaction();

            try
            {
                MySqlCommand command = connect.getconnection.CreateCommand();
                command.Transaction = transaction;

                // Delete from student table
                command.CommandText = "DELETE FROM `student` WHERE `UserID` = @userId";
                command.Parameters.AddWithValue("@userId", userId);
                command.ExecuteNonQuery();

                // Delete from teacher table
                command.CommandText = "DELETE FROM `teacher` WHERE `UserID` = @userId";
                command.ExecuteNonQuery();

                // Delete from admin table
                command.CommandText = "DELETE FROM `admin` WHERE `UserID` = @userId";
                command.ExecuteNonQuery();

                // Delete from user table
                command.CommandText = "DELETE FROM `user` WHERE `UserID` = @userId";
                command.ExecuteNonQuery();

                // Commit the changes made within the transaction to the database
                transaction.Commit();
                return true;
            }
            finally
            {
                connect.closeConnect();
            }
        }

        // Delete teacher from the database
        public bool DeleteTeacher(int userId)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `teacher` WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", userId);

            connect.openConnect();
            int rowsAffected = command.ExecuteNonQuery();
            connect.closeConnect();

            return rowsAffected > 0;
        }

        // Delete admin from the database
        public bool DeleteAdmin(int userId)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `admin` WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", userId);

            connect.openConnect();
            int rowsAffected = command.ExecuteNonQuery();
            connect.closeConnect();

            return rowsAffected > 0;
        }

        // Delete student from the database
        public bool DeleteStudent(int userId)
        {
            MySqlCommand command = new MySqlCommand("DELETE FROM `student` WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", userId);

            connect.openConnect();
            int rowsAffected = command.ExecuteNonQuery();
            connect.closeConnect();

            return rowsAffected > 0;
        }

        //Fill information by entering userid
        public Person GetUserDataByID(int userId)
        {
            Person userData = null; // Initialize to null

            // Open connection
            connect.openConnect();

            // Query to select user data
            MySqlCommand command = new MySqlCommand("SELECT * FROM `user` WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", userId);

            // Execute the query
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                // Check if there are rows returned
                if (reader.Read())
                {
                    // Retrieve the image byte array
                    byte[] imageBytes = reader["Picture"] as byte[];

                    // Populate the Person object with data from the database
                    userData = new Person(
                        Convert.ToInt32(reader["UserID"]),
                        reader["Name"].ToString(),
                        reader["Phone"].ToString(),
                        reader["Email"].ToString(),
                        reader["Role"].ToString(),
                        Convert.ToDateTime(reader["Birthday"]),
                        imageBytes // Set the image byte array
                    );
                }
            }

            // Close connection
            connect.closeConnect();

            return userData;
        }

        // Get user-specific data from the database based on role
        public DataTable GetUserData(string role, string userId)
        {
            DataTable userData = new DataTable();

            // Check the role and execute the appropriate query
            switch (role)
            {
                case "teacher":
                    MySqlCommand teacherCommand = new MySqlCommand("SELECT * FROM teacher WHERE UserID = @userId", connect.getconnection);
                    teacherCommand.Parameters.AddWithValue("@userId", userId);
                    MySqlDataAdapter teacherAdapter = new MySqlDataAdapter(teacherCommand);
                    teacherAdapter.Fill(userData);
                    break;
                case "admin":
                    MySqlCommand adminCommand = new MySqlCommand("SELECT * FROM admin WHERE UserID = @userId", connect.getconnection);
                    adminCommand.Parameters.AddWithValue("@userId", userId);
                    MySqlDataAdapter adminAdapter = new MySqlDataAdapter(adminCommand);
                    adminAdapter.Fill(userData);
                    break;
                case "student":
                    MySqlCommand studentCommand = new MySqlCommand("SELECT * FROM student WHERE UserID = @userId", connect.getconnection);
                    studentCommand.Parameters.AddWithValue("@userId", userId);
                    MySqlDataAdapter studentAdapter = new MySqlDataAdapter(studentCommand);
                    studentAdapter.Fill(userData);
                    break;
                default:
                    // If role is not recognized, return empty DataTable
                    break;
            }

            return userData;
        }

        public string GetUserRole(int userId)
        {
            string role = null; // Initialize to null

            // Open connection
            connect.openConnect();

            // Query to select user role
            MySqlCommand command = new MySqlCommand("SELECT Role FROM `user` WHERE `UserID` = @userId", connect.getconnection);
            command.Parameters.AddWithValue("@userId", userId);

            // Execute the query
            using (MySqlDataReader reader = command.ExecuteReader())
            {
                // Check if there are rows returned
                if (reader.Read())
                {
                    // Retrieve the role from the database
                    role = reader["Role"].ToString();
                }
            }

            // Close connection
            connect.closeConnect();

            return role;
        }
    }
}
