﻿using System;

namespace Transparent_Form.Classes
{
    // Base class representing a user
    public class Person
    {
        // Properties common to all users

        public int UserID { get; set; }
        public string Name { get; set; }
        public string Telephone { get; set; }
        public string Email { get; set; }
        public string Role { get; set; }
        public DateTime Birthday { get; set; }
       
        public byte[] Picture { get; set; }

        // Constructor
        public Person(int userID, string name, string telephone, string email, string role, DateTime birthday, byte[] picture)
        {
            UserID = userID;
            Name = name;
            Telephone = telephone;
            Email = email;
            Role = role;
            Birthday = birthday;
            Picture = picture;
        }

        // Method to display user information
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Name: {Name}");
            Console.WriteLine($"Telephone: {Telephone}");
            Console.WriteLine($"Email: {Email}");
            Console.WriteLine($"Role: {Role}");
            Console.WriteLine($"Birthday: {Birthday.ToShortDateString()}");
            
        }
    }
}