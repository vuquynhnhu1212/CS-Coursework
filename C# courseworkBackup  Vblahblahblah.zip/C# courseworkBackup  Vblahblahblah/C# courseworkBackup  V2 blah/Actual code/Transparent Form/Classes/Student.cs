﻿using System;

namespace Transparent_Form.Classes
{
    // Derived class representing a student
    public class Student : Person
    {
        // Properties specific to students
        public string CurrentSubject1 { get; set; }
        public string CurrentSubject2 { get; set; }
        public string PreviousSubject1 { get; set; }
        public string PreviousSubject2 { get; set; }

        // Constructor
        public Student(int userID, string name, string telephone, string email, string role, DateTime birthday, byte[] picture, string currentSubject1, string currentSubject2, string previousSubject1, string previousSubject2)
            : base(userID, name, telephone, email, role, birthday, picture)
        {
            CurrentSubject1 = currentSubject1;
            CurrentSubject2 = currentSubject2;
            PreviousSubject1 = previousSubject1;
            PreviousSubject2 = previousSubject2;
        }

        // Override method to display student information
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Current Subject 1: {CurrentSubject1}");
            Console.WriteLine($"Current Subject 2: {CurrentSubject2}");
            Console.WriteLine($"Previous Subject 1: {PreviousSubject1}");
            Console.WriteLine($"Previous Subject 2: {PreviousSubject2}");
        }
    }
}