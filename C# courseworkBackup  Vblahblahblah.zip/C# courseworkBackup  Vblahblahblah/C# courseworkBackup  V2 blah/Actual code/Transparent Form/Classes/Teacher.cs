﻿using System;

namespace Transparent_Form.Classes
{
    // Derived class representing a teacher
    public class Teacher : Person
    {
        // Properties specific to teachers
        public decimal Salary { get; set; }
        public string Subject1 { get; set; }
        public string Subject2 { get; set; }

        // Constructor
        public Teacher(int userID, string name, string telephone, string email, string role, DateTime birthday, byte[] picture, decimal salary, string subject1, string subject2)
            : base(userID, name, telephone, email, role, birthday, picture)
        {
            Salary = salary;
            Subject1 = subject1;
            Subject2 = subject2;
        }

        // Override method to display teacher information
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Salary: {Salary:C}");
            Console.WriteLine($"Subject 1: {Subject1}");
            Console.WriteLine($"Subject 2: {Subject2}");
        }
    }
}