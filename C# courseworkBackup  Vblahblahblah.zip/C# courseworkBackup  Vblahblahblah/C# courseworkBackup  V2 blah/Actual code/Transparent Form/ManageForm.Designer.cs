﻿namespace Transparent_Form
{
    partial class ManageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_enter = new System.Windows.Forms.Button();
            this.label_ID = new System.Windows.Forms.Label();
            this.textBox_ID = new System.Windows.Forms.TextBox();
            this.groupBoxStudent = new System.Windows.Forms.GroupBox();
            this.textBox_PreSubject2 = new System.Windows.Forms.TextBox();
            this.textBox_PreSubject1 = new System.Windows.Forms.TextBox();
            this.textBox_CSubject2 = new System.Windows.Forms.TextBox();
            this.textBox_CSubject1 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBoxGender = new System.Windows.Forms.GroupBox();
            this.textBox_Phone = new System.Windows.Forms.TextBox();
            this.button_clear = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.comboBoxRole = new System.Windows.Forms.ComboBox();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_upload = new System.Windows.Forms.Button();
            this.pictureProfile = new System.Windows.Forms.PictureBox();
            this.dateofbirth = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBoxTeacher = new System.Windows.Forms.GroupBox();
            this.textBox_Subject2 = new System.Windows.Forms.TextBox();
            this.textBox_Subject1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_SalaryT = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox_Email = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_Name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBoxTableType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.DataGridView = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBoxAdmin = new System.Windows.Forms.GroupBox();
            this.groupBoxHour = new System.Windows.Forms.GroupBox();
            this.Night = new System.Windows.Forms.RadioButton();
            this.Afternoon = new System.Windows.Forms.RadioButton();
            this.Morning = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBoxWork = new System.Windows.Forms.GroupBox();
            this.FulltimeButton = new System.Windows.Forms.RadioButton();
            this.ParttimeButton = new System.Windows.Forms.RadioButton();
            this.textBox_SalaryA = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBoxStudent.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureProfile)).BeginInit();
            this.groupBoxTeacher.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBoxAdmin.SuspendLayout();
            this.groupBoxHour.SuspendLayout();
            this.groupBoxWork.SuspendLayout();
            this.SuspendLayout();
            // 
            // button_enter
            // 
            this.button_enter.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_enter.BackColor = System.Drawing.Color.Black;
            this.button_enter.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.button_enter.ForeColor = System.Drawing.SystemColors.Control;
            this.button_enter.Location = new System.Drawing.Point(601, 17);
            this.button_enter.Name = "button_enter";
            this.button_enter.Size = new System.Drawing.Size(122, 44);
            this.button_enter.TabIndex = 78;
            this.button_enter.Text = "Enter";
            this.button_enter.UseVisualStyleBackColor = false;
            this.button_enter.Click += new System.EventHandler(this.button_enter_Click);
            // 
            // label_ID
            // 
            this.label_ID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label_ID.AutoSize = true;
            this.label_ID.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label_ID.Location = new System.Drawing.Point(323, 28);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(43, 28);
            this.label_ID.TabIndex = 76;
            this.label_ID.Text = "ID:";
            // 
            // textBox_ID
            // 
            this.textBox_ID.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_ID.Location = new System.Drawing.Point(366, 30);
            this.textBox_ID.Name = "textBox_ID";
            this.textBox_ID.Size = new System.Drawing.Size(229, 26);
            this.textBox_ID.TabIndex = 75;
            this.textBox_ID.TextChanged += new System.EventHandler(this.textBox_ID_TextChanged);
            // 
            // groupBoxStudent
            // 
            this.groupBoxStudent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBoxStudent.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxStudent.Controls.Add(this.textBox_PreSubject2);
            this.groupBoxStudent.Controls.Add(this.textBox_PreSubject1);
            this.groupBoxStudent.Controls.Add(this.textBox_CSubject2);
            this.groupBoxStudent.Controls.Add(this.textBox_CSubject1);
            this.groupBoxStudent.Controls.Add(this.groupBox2);
            this.groupBoxStudent.Controls.Add(this.label10);
            this.groupBoxStudent.Controls.Add(this.label20);
            this.groupBoxStudent.Controls.Add(this.groupBoxGender);
            this.groupBoxStudent.Location = new System.Drawing.Point(12, 154);
            this.groupBoxStudent.Name = "groupBoxStudent";
            this.groupBoxStudent.Size = new System.Drawing.Size(773, 133);
            this.groupBoxStudent.TabIndex = 74;
            this.groupBoxStudent.TabStop = false;
            // 
            // textBox_PreSubject2
            // 
            this.textBox_PreSubject2.Location = new System.Drawing.Point(517, 58);
            this.textBox_PreSubject2.Name = "textBox_PreSubject2";
            this.textBox_PreSubject2.Size = new System.Drawing.Size(221, 26);
            this.textBox_PreSubject2.TabIndex = 82;
            // 
            // textBox_PreSubject1
            // 
            this.textBox_PreSubject1.Location = new System.Drawing.Point(517, 18);
            this.textBox_PreSubject1.Name = "textBox_PreSubject1";
            this.textBox_PreSubject1.Size = new System.Drawing.Size(221, 26);
            this.textBox_PreSubject1.TabIndex = 81;
            // 
            // textBox_CSubject2
            // 
            this.textBox_CSubject2.Location = new System.Drawing.Point(93, 58);
            this.textBox_CSubject2.Name = "textBox_CSubject2";
            this.textBox_CSubject2.Size = new System.Drawing.Size(221, 26);
            this.textBox_CSubject2.TabIndex = 80;
            // 
            // textBox_CSubject1
            // 
            this.textBox_CSubject1.Location = new System.Drawing.Point(93, 18);
            this.textBox_CSubject1.Name = "textBox_CSubject1";
            this.textBox_CSubject1.Size = new System.Drawing.Size(221, 26);
            this.textBox_CSubject1.TabIndex = 79;
            // 
            // groupBox2
            // 
            this.groupBox2.Location = new System.Drawing.Point(744, 110);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(218, 31);
            this.groupBox2.TabIndex = 55;
            this.groupBox2.TabStop = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.label10.Location = new System.Drawing.Point(320, 18);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(191, 26);
            this.label10.TabIndex = 34;
            this.label10.Text = "Previous Subject:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(1, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(98, 26);
            this.label20.TabIndex = 31;
            this.label20.Text = "Subject:";
            // 
            // groupBoxGender
            // 
            this.groupBoxGender.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBoxGender.Location = new System.Drawing.Point(593, 132);
            this.groupBoxGender.Name = "groupBoxGender";
            this.groupBoxGender.Size = new System.Drawing.Size(203, 31);
            this.groupBoxGender.TabIndex = 69;
            this.groupBoxGender.TabStop = false;
            // 
            // textBox_Phone
            // 
            this.textBox_Phone.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Phone.Location = new System.Drawing.Point(222, 128);
            this.textBox_Phone.Name = "textBox_Phone";
            this.textBox_Phone.Size = new System.Drawing.Size(221, 26);
            this.textBox_Phone.TabIndex = 61;
            this.textBox_Phone.TextChanged += new System.EventHandler(this.textBox_Phone_TextChanged);
            // 
            // button_clear
            // 
            this.button_clear.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_clear.BackColor = System.Drawing.Color.Black;
            this.button_clear.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.button_clear.ForeColor = System.Drawing.SystemColors.Control;
            this.button_clear.Location = new System.Drawing.Point(729, 17);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(122, 44);
            this.button_clear.TabIndex = 77;
            this.button_clear.Text = "Clear";
            this.button_clear.UseVisualStyleBackColor = false;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // button_update
            // 
            this.button_update.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_update.BackColor = System.Drawing.Color.Black;
            this.button_update.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.button_update.ForeColor = System.Drawing.SystemColors.Control;
            this.button_update.Location = new System.Drawing.Point(601, 102);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(122, 46);
            this.button_update.TabIndex = 67;
            this.button_update.Text = "Update";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // comboBoxRole
            // 
            this.comboBoxRole.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.comboBoxRole.FormattingEnabled = true;
            this.comboBoxRole.Location = new System.Drawing.Point(96, 28);
            this.comboBoxRole.Name = "comboBoxRole";
            this.comboBoxRole.Size = new System.Drawing.Size(221, 28);
            this.comboBoxRole.TabIndex = 72;
            this.comboBoxRole.SelectedIndexChanged += new System.EventHandler(this.comboBoxRole_SelectedIndexChanged);
            // 
            // button_delete
            // 
            this.button_delete.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_delete.BackColor = System.Drawing.Color.Black;
            this.button_delete.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.button_delete.ForeColor = System.Drawing.SystemColors.Control;
            this.button_delete.Location = new System.Drawing.Point(729, 66);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(122, 44);
            this.button_delete.TabIndex = 68;
            this.button_delete.Text = "Delete";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_upload
            // 
            this.button_upload.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.button_upload.BackColor = System.Drawing.Color.Black;
            this.button_upload.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.button_upload.ForeColor = System.Drawing.SystemColors.Control;
            this.button_upload.Location = new System.Drawing.Point(861, 153);
            this.button_upload.Name = "button_upload";
            this.button_upload.Size = new System.Drawing.Size(122, 46);
            this.button_upload.TabIndex = 66;
            this.button_upload.Text = "Upload";
            this.button_upload.UseVisualStyleBackColor = false;
            this.button_upload.Click += new System.EventHandler(this.button_upload_Click);
            // 
            // pictureProfile
            // 
            this.pictureProfile.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureProfile.BackColor = System.Drawing.SystemColors.ControlDark;
            this.pictureProfile.Location = new System.Drawing.Point(861, 19);
            this.pictureProfile.Name = "pictureProfile";
            this.pictureProfile.Size = new System.Drawing.Size(122, 128);
            this.pictureProfile.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureProfile.TabIndex = 65;
            this.pictureProfile.TabStop = false;
            // 
            // dateofbirth
            // 
            this.dateofbirth.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateofbirth.Font = new System.Drawing.Font("Century Gothic", 8F);
            this.dateofbirth.Location = new System.Drawing.Point(193, 98);
            this.dateofbirth.Name = "dateofbirth";
            this.dateofbirth.Size = new System.Drawing.Size(281, 27);
            this.dateofbirth.TabIndex = 64;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(26, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 28);
            this.label7.TabIndex = 63;
            this.label7.Text = "Role:";
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(27, 126);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(191, 28);
            this.label5.TabIndex = 60;
            this.label5.Text = "Phone Number:";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(23, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 28);
            this.label4.TabIndex = 59;
            this.label4.Text = "Date Of Birth:";
            // 
            // groupBoxTeacher
            // 
            this.groupBoxTeacher.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBoxTeacher.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxTeacher.Controls.Add(this.textBox_Subject2);
            this.groupBoxTeacher.Controls.Add(this.textBox_Subject1);
            this.groupBoxTeacher.Controls.Add(this.label11);
            this.groupBoxTeacher.Controls.Add(this.textBox_SalaryT);
            this.groupBoxTeacher.Controls.Add(this.label8);
            this.groupBoxTeacher.Location = new System.Drawing.Point(12, 154);
            this.groupBoxTeacher.Name = "groupBoxTeacher";
            this.groupBoxTeacher.Size = new System.Drawing.Size(749, 154);
            this.groupBoxTeacher.TabIndex = 70;
            this.groupBoxTeacher.TabStop = false;
            // 
            // textBox_Subject2
            // 
            this.textBox_Subject2.Location = new System.Drawing.Point(518, 62);
            this.textBox_Subject2.Name = "textBox_Subject2";
            this.textBox_Subject2.Size = new System.Drawing.Size(221, 26);
            this.textBox_Subject2.TabIndex = 78;
            // 
            // textBox_Subject1
            // 
            this.textBox_Subject1.Location = new System.Drawing.Point(518, 22);
            this.textBox_Subject1.Name = "textBox_Subject1";
            this.textBox_Subject1.Size = new System.Drawing.Size(221, 26);
            this.textBox_Subject1.TabIndex = 77;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(408, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 28);
            this.label11.TabIndex = 30;
            this.label11.Text = "Subject:";
            // 
            // textBox_SalaryT
            // 
            this.textBox_SalaryT.Location = new System.Drawing.Point(97, 25);
            this.textBox_SalaryT.Name = "textBox_SalaryT";
            this.textBox_SalaryT.Size = new System.Drawing.Size(221, 26);
            this.textBox_SalaryT.TabIndex = 29;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(-1, 27);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 28);
            this.label8.TabIndex = 28;
            this.label8.Text = "Salary:";
            // 
            // textBox_Email
            // 
            this.textBox_Email.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Email.Location = new System.Drawing.Point(458, 66);
            this.textBox_Email.Name = "textBox_Email";
            this.textBox_Email.Size = new System.Drawing.Size(229, 26);
            this.textBox_Email.TabIndex = 58;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(373, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 28);
            this.label3.TabIndex = 57;
            this.label3.Text = "Email:";
            // 
            // textBox_Name
            // 
            this.textBox_Name.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.textBox_Name.Location = new System.Drawing.Point(146, 64);
            this.textBox_Name.Name = "textBox_Name";
            this.textBox_Name.Size = new System.Drawing.Size(221, 26);
            this.textBox_Name.TabIndex = 56;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(27, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(91, 28);
            this.label2.TabIndex = 55;
            this.label2.Text = "Name:";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(13, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1112, 10);
            this.panel3.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.comboBoxTableType);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1137, 49);
            this.panel1.TabIndex = 41;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.SystemColors.Control;
            this.label14.Location = new System.Drawing.Point(12, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(82, 28);
            this.label14.TabIndex = 53;
            this.label14.Text = "Table:";
            // 
            // comboBoxTableType
            // 
            this.comboBoxTableType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBoxTableType.FormattingEnabled = true;
            this.comboBoxTableType.Location = new System.Drawing.Point(97, 10);
            this.comboBoxTableType.Name = "comboBoxTableType";
            this.comboBoxTableType.Size = new System.Drawing.Size(223, 28);
            this.comboBoxTableType.TabIndex = 53;
            this.comboBoxTableType.SelectedIndexChanged += new System.EventHandler(this.comboBoxTableType_SelectedIndexChanged_1);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.SystemColors.Control;
            this.label12.Location = new System.Drawing.Point(801, 10);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(198, 34);
            this.label12.TabIndex = 36;
            this.label12.Text = "Management";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // DataGridView
            // 
            this.DataGridView.AllowUserToAddRows = false;
            this.DataGridView.AllowUserToDeleteRows = false;
            this.DataGridView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView.Location = new System.Drawing.Point(13, 59);
            this.DataGridView.Name = "DataGridView";
            this.DataGridView.ReadOnly = true;
            this.DataGridView.RowHeadersWidth = 62;
            this.DataGridView.RowTemplate.Height = 60;
            this.DataGridView.Size = new System.Drawing.Size(1112, 226);
            this.DataGridView.TabIndex = 42;
            this.DataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.groupBoxAdmin);
            this.panel2.Controls.Add(this.groupBoxStudent);
            this.panel2.Controls.Add(this.button_enter);
            this.panel2.Controls.Add(this.button_clear);
            this.panel2.Controls.Add(this.label_ID);
            this.panel2.Controls.Add(this.textBox_ID);
            this.panel2.Controls.Add(this.textBox_Phone);
            this.panel2.Controls.Add(this.button_update);
            this.panel2.Controls.Add(this.comboBoxRole);
            this.panel2.Controls.Add(this.groupBoxTeacher);
            this.panel2.Controls.Add(this.button_delete);
            this.panel2.Controls.Add(this.button_upload);
            this.panel2.Controls.Add(this.pictureProfile);
            this.panel2.Controls.Add(this.dateofbirth);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.textBox_Email);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.textBox_Name);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 288);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1137, 300);
            this.panel2.TabIndex = 43;
            // 
            // groupBoxAdmin
            // 
            this.groupBoxAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBoxAdmin.BackColor = System.Drawing.SystemColors.Control;
            this.groupBoxAdmin.Controls.Add(this.groupBoxHour);
            this.groupBoxAdmin.Controls.Add(this.label13);
            this.groupBoxAdmin.Controls.Add(this.label9);
            this.groupBoxAdmin.Controls.Add(this.groupBoxWork);
            this.groupBoxAdmin.Controls.Add(this.textBox_SalaryA);
            this.groupBoxAdmin.Controls.Add(this.label18);
            this.groupBoxAdmin.Location = new System.Drawing.Point(12, 154);
            this.groupBoxAdmin.Name = "groupBoxAdmin";
            this.groupBoxAdmin.Size = new System.Drawing.Size(765, 134);
            this.groupBoxAdmin.TabIndex = 79;
            this.groupBoxAdmin.TabStop = false;
            // 
            // groupBoxHour
            // 
            this.groupBoxHour.Controls.Add(this.Night);
            this.groupBoxHour.Controls.Add(this.Afternoon);
            this.groupBoxHour.Controls.Add(this.Morning);
            this.groupBoxHour.Location = new System.Drawing.Point(181, 32);
            this.groupBoxHour.Name = "groupBoxHour";
            this.groupBoxHour.Size = new System.Drawing.Size(408, 31);
            this.groupBoxHour.TabIndex = 55;
            this.groupBoxHour.TabStop = false;
            // 
            // Night
            // 
            this.Night.AutoSize = true;
            this.Night.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.Night.Location = new System.Drawing.Point(274, 5);
            this.Night.Name = "Night";
            this.Night.Size = new System.Drawing.Size(123, 26);
            this.Night.TabIndex = 43;
            this.Night.Text = "1:00 - 9:00";
            this.Night.UseVisualStyleBackColor = true;
            this.Night.CheckedChanged += new System.EventHandler(this.Night_CheckedChanged);
            // 
            // Afternoon
            // 
            this.Afternoon.AutoSize = true;
            this.Afternoon.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.Afternoon.Location = new System.Drawing.Point(135, 5);
            this.Afternoon.Name = "Afternoon";
            this.Afternoon.Size = new System.Drawing.Size(133, 26);
            this.Afternoon.TabIndex = 42;
            this.Afternoon.Text = "17:00 - 1:00";
            this.Afternoon.UseVisualStyleBackColor = true;
            this.Afternoon.CheckedChanged += new System.EventHandler(this.Afternoon_CheckedChanged);
            // 
            // Morning
            // 
            this.Morning.AutoSize = true;
            this.Morning.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.Morning.Location = new System.Drawing.Point(0, 5);
            this.Morning.Name = "Morning";
            this.Morning.Size = new System.Drawing.Size(133, 26);
            this.Morning.TabIndex = 41;
            this.Morning.Text = "9:00 - 17:00";
            this.Morning.UseVisualStyleBackColor = true;
            this.Morning.CheckedChanged += new System.EventHandler(this.Morning_CheckedChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(6, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(160, 26);
            this.label13.TabIndex = 53;
            this.label13.Text = "Working Hour:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(340, 73);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 28);
            this.label9.TabIndex = 52;
            this.label9.Text = "Work:";
            // 
            // groupBoxWork
            // 
            this.groupBoxWork.Controls.Add(this.FulltimeButton);
            this.groupBoxWork.Controls.Add(this.ParttimeButton);
            this.groupBoxWork.Location = new System.Drawing.Point(437, 69);
            this.groupBoxWork.Name = "groupBoxWork";
            this.groupBoxWork.Size = new System.Drawing.Size(238, 31);
            this.groupBoxWork.TabIndex = 56;
            this.groupBoxWork.TabStop = false;
            // 
            // FulltimeButton
            // 
            this.FulltimeButton.AutoSize = true;
            this.FulltimeButton.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.FulltimeButton.Location = new System.Drawing.Point(126, 6);
            this.FulltimeButton.Name = "FulltimeButton";
            this.FulltimeButton.Size = new System.Drawing.Size(112, 26);
            this.FulltimeButton.TabIndex = 25;
            this.FulltimeButton.Text = "Full-Time";
            this.FulltimeButton.UseVisualStyleBackColor = true;
            // 
            // ParttimeButton
            // 
            this.ParttimeButton.AutoSize = true;
            this.ParttimeButton.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold);
            this.ParttimeButton.Location = new System.Drawing.Point(3, 6);
            this.ParttimeButton.Name = "ParttimeButton";
            this.ParttimeButton.Size = new System.Drawing.Size(117, 26);
            this.ParttimeButton.TabIndex = 24;
            this.ParttimeButton.Text = "Part-Time";
            this.ParttimeButton.UseVisualStyleBackColor = true;
            // 
            // textBox_SalaryA
            // 
            this.textBox_SalaryA.Location = new System.Drawing.Point(103, 74);
            this.textBox_SalaryA.Name = "textBox_SalaryA";
            this.textBox_SalaryA.Size = new System.Drawing.Size(221, 26);
            this.textBox_SalaryA.TabIndex = 51;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(6, 74);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(91, 28);
            this.label18.TabIndex = 50;
            this.label18.Text = "Salary:";
            // 
            // ManageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1137, 588);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.DataGridView);
            this.Controls.Add(this.panel2);
            this.MinimumSize = new System.Drawing.Size(1159, 644);
            this.Name = "ManageForm";
            this.Text = "Manage User Form";
            this.groupBoxStudent.ResumeLayout(false);
            this.groupBoxStudent.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureProfile)).EndInit();
            this.groupBoxTeacher.ResumeLayout(false);
            this.groupBoxTeacher.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBoxAdmin.ResumeLayout(false);
            this.groupBoxAdmin.PerformLayout();
            this.groupBoxHour.ResumeLayout(false);
            this.groupBoxHour.PerformLayout();
            this.groupBoxWork.ResumeLayout(false);
            this.groupBoxWork.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_enter;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.TextBox textBox_ID;
        private System.Windows.Forms.GroupBox groupBoxStudent;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBoxGender;
        private System.Windows.Forms.TextBox textBox_Phone;
        private System.Windows.Forms.Button button_clear;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.ComboBox comboBoxRole;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_upload;
        private System.Windows.Forms.PictureBox pictureProfile;
        private System.Windows.Forms.DateTimePicker dateofbirth;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBoxTeacher;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_SalaryT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox_Email;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBoxTableType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView DataGridView;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox_Subject1;
        private System.Windows.Forms.TextBox textBox_PreSubject2;
        private System.Windows.Forms.TextBox textBox_PreSubject1;
        private System.Windows.Forms.TextBox textBox_CSubject2;
        private System.Windows.Forms.TextBox textBox_CSubject1;
        private System.Windows.Forms.TextBox textBox_Subject2;
        private System.Windows.Forms.GroupBox groupBoxAdmin;
        private System.Windows.Forms.GroupBox groupBoxHour;
        private System.Windows.Forms.RadioButton Night;
        private System.Windows.Forms.RadioButton Morning;
        private System.Windows.Forms.RadioButton Afternoon;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.GroupBox groupBoxWork;
        private System.Windows.Forms.RadioButton FulltimeButton;
        private System.Windows.Forms.RadioButton ParttimeButton;
        private System.Windows.Forms.TextBox textBox_SalaryA;
        private System.Windows.Forms.Label label18;
    }
}