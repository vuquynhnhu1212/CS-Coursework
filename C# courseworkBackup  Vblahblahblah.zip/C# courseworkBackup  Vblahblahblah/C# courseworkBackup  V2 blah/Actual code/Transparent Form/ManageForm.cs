﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Transparent_Form.Classes;

namespace Transparent_Form
{
    // Partial class for the registration form
    public partial class ManageForm : Form
    {
        // DatabaseClass for database operations
        DatabaseClass dbClass = new DatabaseClass();

        // Default table type for data display
        private string selectedTableType = "user";

        // Constructor for the manage form
        public ManageForm()
        {
            InitializeComponent();

            // Initialize the ComboBox for role selection
            comboBoxRole.Items.AddRange(new string[] { "teacher", "admin", "student" });
            comboBoxRole.SelectedIndex = 0;
            // Initialize the ComboBox for table selection
            comboBoxTableType.Items.AddRange(new string[] { "user", "teacher", "admin", "student" });
            comboBoxTableType.SelectedIndex = 0;
        }

        // Event handler for when the table type ComboBox selection changes
        private void comboBoxTableType_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Update the selected table type when the user selects a different table type
            selectedTableType = comboBoxTableType.SelectedItem.ToString();
            showTable();
        }

        // Event handler for loading database table at the start
        private void ManageForm_Load(object sender, EventArgs e)
        {
            showTable();
        }

        // Method to validate phone number format
        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return phoneNumber.Length == 10;
        }

        // Method to validate email format
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            int atIndex = email.IndexOf('@');
            if (atIndex == -1 || atIndex == 0 || atIndex == email.Length - 1)
                return false;

            string[] parts = email.Split('@');
            if (parts.Length != 2)
                return false;

            string domain = parts[1];
            int dotIndex = domain.IndexOf('.');
            if (dotIndex == -1 || dotIndex == 0 || dotIndex == domain.Length - 1)
                return false;

            return true;
        }

        // Method to get the text of the selected radio button in a group box
        private string GetSelectedRadioButtonText(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton radioButton && radioButton.Checked)
                {
                    return radioButton.Text;
                }
            }
            return "";
        }

        // Method to get the selected role from the ComboBox
        private string GetSelectedRole()
        {
            return comboBoxRole.SelectedItem?.ToString();
        }

        // Method to clear all input fields and radio button selections
        private void ClearFields()
        {
            textBox_Name.Text = "";
            textBox_Email.Text = "";
            dateofbirth.Value = DateTime.Now;
            textBox_Phone.Text = "";
            textBox_Subject1.Text = "";
            textBox_Subject2.Text = "";
            textBox_CSubject1.Text = "";
            textBox_CSubject2.Text = "";
            textBox_SalaryA.Text = "";
            textBox_SalaryT.Text = "";
            textBox_PreSubject1.Text = "";
            textBox_PreSubject2.Text = "";
            pictureProfile.Image = null;

            // Clear radio button selections
            ClearRadioButtons(groupBoxWork);
            ClearRadioButtons(groupBoxHour);
        }

        // Method to clear radio button selections within a group box
        private void ClearRadioButtons(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton radioButton)
                {
                    radioButton.Checked = false;
                }
            }
        }

        // Method to verify if all required fields are filled
        private bool verify()
        {
            switch (GetSelectedRole())
            {
                case "teacher":
                    return !string.IsNullOrWhiteSpace(textBox_Name.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Email.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Phone.Text)
                        
                        && !string.IsNullOrWhiteSpace(textBox_SalaryT.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Subject1.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Subject2.Text)
                        && pictureProfile.Image != null;
                case "admin":
                    return !string.IsNullOrWhiteSpace(textBox_Name.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Email.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Phone.Text)
                        
                        && !string.IsNullOrWhiteSpace(textBox_SalaryA.Text)
                        && (ParttimeButton.Checked || FulltimeButton.Checked)
                        && (Morning.Checked || Afternoon.Checked || Night.Checked)
                        && pictureProfile.Image != null;
                case "student":
                    return !string.IsNullOrWhiteSpace(textBox_Name.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Email.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Phone.Text)
                       
                        && !string.IsNullOrWhiteSpace(textBox_CSubject1.Text)
                        && !string.IsNullOrWhiteSpace(textBox_CSubject2.Text)
                        && !string.IsNullOrWhiteSpace(textBox_PreSubject1.Text)
                        && !string.IsNullOrWhiteSpace(textBox_PreSubject2.Text)
                        && pictureProfile.Image != null;
                default:
                    return false; // Handle other roles or no role selected
            }
        }

        // To display table and refresh different table type
        private void showTable()
        {
            switch (selectedTableType)
            {
                case "teacher":
                    DataGridView.DataSource = dbClass.GetTeacherList();
                    break;
                case "admin":
                    DataGridView.DataSource = dbClass.GetAdminList();
                    break;
                case "student":
                    DataGridView.DataSource = dbClass.GetStudentList();
                    break;
                default:
                    DataGridView.DataSource = dbClass.GetUserList();
                    DataGridViewImageColumn column = (DataGridViewImageColumn)DataGridView.Columns["Picture"];
                    column.ImageLayout = DataGridViewImageCellLayout.Zoom;
                    break;
            }
        }

        private void comboBoxRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Hide all group boxes first
            groupBoxTeacher.Visible = false;
            groupBoxAdmin.Visible = false;
            groupBoxStudent.Visible = false;

            // Show the group box corresponding to the selected role
            switch (comboBoxRole.SelectedItem?.ToString())
            {
                case "teacher":
                    groupBoxTeacher.Visible = true;
                    break;
                case "admin":
                    groupBoxAdmin.Visible = true;
                    break;
                case "student":
                    groupBoxStudent.Visible = true;
                    break;
                default:
                    break;
            }
        }

        private void button_enter_Click(object sender, EventArgs e)
        {
            // Check if the ID text box is not empty
            if (!string.IsNullOrEmpty(textBox_ID.Text))
            {
                // Retrieve the entered ID from the text box
                int userId;
                if (int.TryParse(textBox_ID.Text, out userId))
                {
                    // Retrieve user-specific data from the database
                    Person userData = dbClass.GetUserDataByID(userId);

                    // Check if data is retrieved
                    if (userData != null)
                    {
                        // Display the user data in appropriate text boxes or controls
                        textBox_Name.Text = userData.Name;
                        textBox_Phone.Text = userData.Telephone;
                        textBox_Email.Text = userData.Email;
                        dateofbirth.Value = userData.Birthday;
                        comboBoxRole.Text = userData.Role;

                        // Set the picture if available
                        if (userData.Picture != null && userData.Picture.Length > 0)
                        {
                            // Convert byte array to image and display
                            using (MemoryStream ms = new MemoryStream(userData.Picture))
                            {
                                pictureProfile.Image = Image.FromStream(ms);
                            }
                        }

                        // Clear role-specific textboxes
                        ClearRoleFields();

                        // Fill role-specific information
                        DataTable roleData = dbClass.GetUserData(userData.Role, userId.ToString());
                        if (roleData.Rows.Count > 0)
                        {
                            DataRow row = roleData.Rows[0];
                            switch (userData.Role)
                            {
                                case "teacher":
                                    textBox_SalaryT.Text = row["Salary"].ToString();
                                    textBox_Subject1.Text = row["Subject1"].ToString();
                                    textBox_Subject2.Text = row["Subject2"].ToString();
                                    break;
                                case "student":
                                    textBox_CSubject1.Text = row["CurrentSubject1"].ToString();
                                    textBox_CSubject2.Text = row["CurrentSubject2"].ToString();
                                    textBox_PreSubject1.Text = row["PreviousSubject1"].ToString();
                                    textBox_PreSubject2.Text = row["PreviousSubject2"].ToString();
                                    break;
                                case "admin":
                                    textBox_SalaryA.Text = row["Salary"].ToString();
                                    if (row["WorkType"].ToString() == "Part-time")
                                        ParttimeButton.Checked = true;
                                    else
                                        FulltimeButton.Checked = true;

                                    // Set the selected radio button for working hours
                                    switch (row["WorkingHours"].ToString())
                                    {
                                        case "9:00 - 17:00":
                                            Morning.Checked = true;
                                            break;
                                        case "17:00 - 1:00":
                                            Afternoon.Checked = true;
                                            break;
                                        case "1:00 - 9:00":
                                            Night.Checked = true;
                                            break;
                                        default:
                                            // Handle other cases or no selection
                                            break;
                                    }
                                    break;
                            }
                        }

                        // You may need to handle the picture display if the Picture property is retrieved from the database

                        // Display a success message
                        MessageBox.Show("User found.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // If no data found for the entered ID, clear the text boxes
                        ClearFields();
                        MessageBox.Show("No user found with the entered ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter the ID of the user to retrieve.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // Helper method to clear role-specific textboxes and radio buttons
        private void ClearRoleFields()
        {
            switch (comboBoxRole.Text)
            {
                case "teacher":
                    textBox_SalaryT.Clear();
                    textBox_Subject1.Clear();
                    textBox_Subject2.Clear();
                    break;
                case "student":
                    textBox_CSubject1.Clear();
                    textBox_CSubject2.Clear();
                    textBox_PreSubject1.Clear();
                    textBox_PreSubject2.Clear();
                    break;
                case "admin":
                    textBox_SalaryA.Clear();
                    ParttimeButton.Checked = false;
                    FulltimeButton.Checked = false;
                    Morning.Checked = false;
                    Afternoon.Checked = false;
                    Night.Checked = false;
                    break;
                default:
                    // Handle other roles if needed
                    break;
            }
        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            // Check if the ID text box is not empty
            if (!string.IsNullOrEmpty(textBox_ID.Text))
            {
                // Retrieve the entered ID from the text box
                int userId;
                if (int.TryParse(textBox_ID.Text, out userId))
                {
                    // Confirm with the user before deleting
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this user?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        // Attempt to delete the user from the database
                        if (dbClass.DeleteUser(userId))
                        {
                            // If deletion is successful, show a success message
                            MessageBox.Show("User deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            // Refresh the displayed table
                            showTable();
                            // Clear the text boxes
                            ClearFields();
                        }
                        else
                        {
                            // If deletion fails, show an error message
                            MessageBox.Show("Failed to delete user.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please enter the ID of the user to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureProfile.Image = new Bitmap(openFileDialog.FileName);
            }
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            // Retrieve user input data
            string userid = textBox_ID.Text;
            string name = textBox_Name.Text;
            string email = textBox_Email.Text;
            DateTime birthday = dateofbirth.Value;
            string telephone = textBox_Phone.Text;

            // Determine the selected role
            string role = GetSelectedRole();

            // Determine the selected work type
            string workType = GetSelectedRadioButtonText(groupBoxWork);

            // Determine the selected working hours
            string workingHours = GetSelectedRadioButtonText(groupBoxHour);

            string salaryA = textBox_SalaryA.Text;
            string salaryT = textBox_SalaryT.Text;

            string Subject1 = textBox_Subject1.Text;
            string Subject2 = textBox_Subject2.Text;

            decimal SalaryDecA;
            decimal.TryParse(salaryA, out SalaryDecA);

            decimal SalaryDecT;
            decimal.TryParse(salaryT, out SalaryDecT);

            // Retrieve subject information
            string currentSubject1 = textBox_CSubject1.Text;
            string currentSubject2 = textBox_CSubject2.Text;
            string previousSubject1 = textBox_PreSubject1.Text;
            string previousSubject2 = textBox_PreSubject2.Text;

            // Verify all fields are filled
            if (!verify())
            {
                MessageBox.Show("Please fill in all fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (SalaryDecT < 0)
            {
                MessageBox.Show("Salary cannot be negative. Please enter a valid positive number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (SalaryDecA < 0)
            {
                MessageBox.Show("Salary cannot be negative. Please enter a valid positive number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate phone number format
            if (!IsValidPhoneNumber(telephone))
            {
                MessageBox.Show("Invalid phone number format. Please enter a 10-digit number.", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate email format
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email address ending with @email.com.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate age
            int bornyear = dateofbirth.Value.Year;
            int thisyear = DateTime.Now.Year;
            if ((thisyear - bornyear) < 1 || (thisyear - bornyear) > 100)
            {
                MessageBox.Show("Age Range should be from 1 to 100.", "Invalid Age", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Convert profile picture to byte array
                MemoryStream ms = new MemoryStream();
                pictureProfile.Image.Save(ms, pictureProfile.Image.RawFormat);
                byte[] picture = ms.ToArray();

                // Retrieve old role
                string oldRole = dbClass.GetUserRole(Convert.ToInt32(userid));

                // Delete old role-specific data only if the role has changed
                if (oldRole != role)
                {
                    switch (oldRole)
                    {
                        case "teacher":
                            if (!dbClass.DeleteTeacher(Convert.ToInt32(userid)))
                            {
                                MessageBox.Show("Failed to delete old teacher data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            break;
                        case "admin":
                            if (!dbClass.DeleteAdmin(Convert.ToInt32(userid)))
                            {
                                MessageBox.Show("Failed to delete old admin data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            break;
                        case "student":
                            if (!dbClass.DeleteStudent(Convert.ToInt32(userid)))
                            {
                                MessageBox.Show("Failed to delete old student data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                            break;
                    }
                }

                // Create a Person object with all the necessary data
                Person person = new Person(
                    Convert.ToInt32(userid),
                    name,
                    telephone,
                    email,
                    role,
                    birthday,
                    picture
                );

                // Update user data in the database
                if (dbClass.UpdateUser(person))
                {
                    // Insert new role-specific data if the role has changed
                    if (oldRole != role)
                    {
                        switch (role)
                        {
                            case "teacher":
                                Teacher newTeacher = new Teacher(
                                    Convert.ToInt32(userid),
                                    name,
                                    telephone,
                                    email,
                                    role,
                                    birthday,
                                    picture,
                                    SalaryDecT,
                                    Subject1,
                                    Subject2
                                );
                                if (!dbClass.InsertTeacher(newTeacher))
                                {
                                    MessageBox.Show("Failed to insert teacher data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                break;
                            case "admin":
                                Admin newAdmin = new Admin(
                                    Convert.ToInt32(userid),
                                    name,
                                    telephone,
                                    email,
                                    role,
                                    birthday,
                                    picture,
                                    SalaryDecA,
                                    workType,
                                    workingHours
                                );
                                if (!dbClass.InsertAdmin(newAdmin))
                                {
                                    MessageBox.Show("Failed to insert admin data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                break;
                            case "student":
                                Student newStudent = new Student(
                                    Convert.ToInt32(userid),
                                    name,
                                    telephone,
                                    email,
                                    role,
                                    birthday,
                                    picture,
                                    currentSubject1,
                                    currentSubject2,
                                    previousSubject1,
                                    previousSubject2
                                );
                                if (!dbClass.InsertStudent(newStudent))
                                {
                                    MessageBox.Show("Failed to insert student data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                                break;
                        }
                    }

                    // Update role-specific data
                    switch (role)
                    {
                        case "teacher":
                            Teacher updatedTeacher = new Teacher(
                                Convert.ToInt32(userid),
                                name,
                                telephone,
                                email,
                                role,
                                birthday,
                                picture,
                                SalaryDecT,
                                Subject1,
                                Subject2
                            );
                            if (dbClass.UpdateTeacherData(updatedTeacher))
                            {
                                MessageBox.Show("Teacher data updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearFields();
                            }
                            else
                            {
                                MessageBox.Show("Failed to update teacher data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            break;
                        case "admin":
                            Admin updatedAdmin = new Admin(
                                Convert.ToInt32(userid),
                                name,
                                telephone,
                                email,
                                role,
                                birthday,
                                picture,
                                SalaryDecA,
                                workType,
                                workingHours
                            );
                            if (dbClass.UpdateAdminData(updatedAdmin))
                            {
                                MessageBox.Show("Admin data updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearFields();
                            }
                            else
                            {
                                MessageBox.Show("Failed to update admin data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            break;
                        case "student":
                            Student updatedStudent = new Student(
                                Convert.ToInt32(userid),
                                name,
                                telephone,
                                email,
                                role,
                                birthday,
                                picture,
                                currentSubject1,
                                currentSubject2,
                                previousSubject1,
                                previousSubject2
                            );
                            if (dbClass.UpdateStudentData(updatedStudent))
                            {
                                MessageBox.Show("Student data updated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearFields();
                            }
                            else
                            {
                                MessageBox.Show("Failed to update student data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            break;
                        default:
                            MessageBox.Show("Please select a role", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                    showTable();
                }
                else
                {
                    MessageBox.Show("Failed to update user data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void DataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox_ID_TextChanged(object sender, EventArgs e)
        {
            // Check if the ID text box is not empty
            if (!string.IsNullOrEmpty(textBox_ID.Text))
            {
                // Retrieve the entered ID from the text box
                int userID;
                if (int.TryParse(textBox_ID.Text, out userID))
                {
                    // Retrieve user-specific data from the database
                    DataTable userData = dbClass.GetUserData("user", textBox_ID.Text);

                    // Check if data is retrieved
                    if (userData.Rows.Count > 0)
                    {
                        // Display the user data in appropriate text boxes or controls
                        DataRow row = userData.Rows[0];
                        textBox_Name.Text = row["Name"].ToString();
                        textBox_Phone.Text = row["Phone"].ToString();
                        textBox_Email.Text = row["Email"].ToString();
                        comboBoxRole.Text = row["Role"].ToString();
                        groupBoxStudent.Text = row["Student"].ToString();
                        groupBoxAdmin.Text = row["Admin"].ToString();
                        groupBoxTeacher.Text = row["Teacher"].ToString();
                        dateofbirth.Value = (DateTime)row["Birthday"];

                        // Check the user's role to populate role-specific fields
                        string role = row["Role"].ToString().ToLower();
                        switch (role)
                        {
                            case "teacher":
                                // Populate teacher-specific fields
                                groupBoxTeacher.Visible = true;
                                groupBoxAdmin.Visible = false;
                                groupBoxStudent.Visible = false;
                                textBox_SalaryT.Text = row["Salary"].ToString();
                                textBox_Subject1.Text = row["Subject1"].ToString();
                                textBox_Subject2.Text = row["Subject2"].ToString();
                                break;
                            case "admin":
                                // Populate admin-specific fields
                                groupBoxTeacher.Visible = false;
                                groupBoxAdmin.Visible = true;
                                groupBoxStudent.Visible = false;
                                textBox_SalaryA.Text = row["Salary"].ToString();

                                // Set the selected radio button for work type
                                string workType = row["WorkType"].ToString().ToLower();
                                switch (workType)
                                {
                                    case "part-time":
                                        ParttimeButton.Checked = true;
                                        break;
                                    case "full-time":
                                        FulltimeButton.Checked = true;
                                        break;
                                    default:
                                        // Handle unrecognized work type
                                        break;
                                }

                                // Set the selected radio button for working hours
                                string workingHours = row["WorkingHours"].ToString().ToLower();
                                switch (workingHours)
                                {
                                    case "morning":
                                        Morning.Checked = true;
                                        break;
                                    case "afternoon":
                                        Afternoon.Checked = true;
                                        break;
                                    case "night":
                                        Night.Checked = true;
                                        break;
                                    default:
                                        // Handle unrecognized working hours
                                        break;
                                }
                                break;
                            case "student":
                                // Populate student-specific fields
                                groupBoxTeacher.Visible = false;
                                groupBoxAdmin.Visible = false;
                                groupBoxStudent.Visible = true;
                                textBox_CSubject1.Text = row["CurrentSubject1"].ToString();
                                textBox_CSubject2.Text = row["CurrentSubject2"].ToString();
                                textBox_PreSubject1.Text = row["PreviousSubject1"].ToString();
                                textBox_PreSubject2.Text = row["PreviousSubject2"].ToString();
                                break;
                            default:
                                // Handle unrecognized roles
                                MessageBox.Show("Unrecognized user role.");
                                break;
                        }
                    }
                }
            }
        }

        private void textBox_Phone_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox_PreSubject1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FulltimeButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ParttimeButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Morning_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Afternoon_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Night_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
