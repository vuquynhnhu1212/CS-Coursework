﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Transparent_Form
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Instantiate MainForm
            MainForm mainForm = new MainForm();

            // Pass MainForm to Application.Run()
            Application.Run(mainForm);
        }
    }
}