﻿using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Transparent_Form.Classes;

namespace Transparent_Form
{
    // Partial class for the registration form
    public partial class RegisterForm : Form
    {
        // DatabaseClass for database operations
        DatabaseClass dbClass = new DatabaseClass();

        // Default table type for data display
        private string selectedTableType = "user";

        // Constructor for the registration form
        public RegisterForm()
        {
            InitializeComponent();

            // Initialize the ComboBox for role selection
            comboBoxRole.Items.AddRange(new string[] { "teacher", "admin", "student" });
            comboBoxRole.SelectedIndex = 0;
            // Initialize the ComboBox for table selection
            comboBoxTableType.Items.AddRange(new string[] { "user", "teacher", "admin", "student" });
            comboBoxTableType.SelectedIndex = 0;
        }

        private void LoadComboBoxItems(ComboBox comboBox, DataTable dataTable)
        {
            comboBox.DisplayMember = "SubjectName";
            comboBox.ValueMember = "SubjectID";
            comboBox.DataSource = dataTable.Copy();
        }

        // Event handler for when the table type ComboBox selection changes
        private void comboBoxTableType_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Update the selected table type when the user selects a different table type
            selectedTableType = comboBoxTableType.SelectedItem.ToString();
            showTable();
        }

        // Event handler for loading database table at the start
        private void RegisterForm_Load(object sender, EventArgs e)
        {
            showTable();
        }

        // Event handler for the Add button click
        private void button_add_Click_1(object sender, EventArgs e)
        {
            // Retrieve user input data
            string name = textBox_Name.Text;
            string email = textBox_Email.Text;
            DateTime birthday = dateofbirth.Value;
            string telephone = textBox_Phone.Text;


            // Determine the selected role
            string role = GetSelectedRole();

            // Determine the selected work type
            string workType = GetSelectedRadioButtonText(groupBoxWork);

            // Determine the selected working hours
            string workingHours = GetSelectedRadioButtonText(groupBoxHour);

            string salaryA = textBox_SalaryA.Text;
            string salaryT = textBox_SalaryT.Text;

            string Subject1 = textBox_Subject1.Text;
            string Subject2 = textBox_Subject2.Text;

            decimal SalaryDecA;
            decimal.TryParse(salaryA, out SalaryDecA);

            decimal SalaryDecT;
            decimal.TryParse(salaryT, out SalaryDecT);

            // Retrieve subject information
            string currentSubject1 = textBox_CSubject1.Text;
            string currentSubject2 = textBox_CSubject2.Text;
            string previousSubject1 = textBox_PreSubject1.Text;
            string previousSubject2 = textBox_PreSubject2.Text;

            // Verify all fields are filled
            if (!verify())
            {
                MessageBox.Show("Please fill in all fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (SalaryDecT < 0)
            {
                MessageBox.Show("Salary cannot be negative. Please enter a valid positive number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (SalaryDecA < 0)
            {
                MessageBox.Show("Salary cannot be negative. Please enter a valid positive number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate phone number format
            if (!IsValidPhoneNumber(telephone))
            {
                MessageBox.Show("Invalid phone number format. Please enter a 10-digit number.", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate email format
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format. Please enter a valid email address ending with @email.com.", "Invalid Email", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate age
            int bornyear = dateofbirth.Value.Year;
            int thisyear = DateTime.Now.Year;
            if ((thisyear - bornyear) < 1 || (thisyear - bornyear) > 100)
            {
                MessageBox.Show("Age Range should be from 1 to 100.", "Invalid Age", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                // Convert profile picture to byte array
                MemoryStream ms = new MemoryStream();
                pictureProfile.Image.Save(ms, pictureProfile.Image.RawFormat);
                byte[] picture = ms.ToArray();

                // Create a Person object with all the necessary data
                Person person = new Person(
                    -1,
                    name,
                    telephone,
                    email,
                    role,
                    birthday,
                    picture
                );

                MessageBox.Show("New person added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                // Insert user data into the database
                int insertedUserId = dbClass.InsertUser(person);

                if (insertedUserId > 0)
                {
                    // Insert role-specific data into corresponding table
                    switch (role)
                    {
                        case "teacher":
                            Teacher teacher = new Teacher(
                                insertedUserId,
                                name,
                                telephone,
                                email,
                                role,
                                birthday,
                                picture,
                                SalaryDecT,
                                Subject1,
                                Subject2
                            );
                            if (dbClass.InsertTeacher(teacher))
                            {
                                MessageBox.Show("New teacher added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearFields();
                            }
                            else
                            {
                                MessageBox.Show("Failed to add teacher role", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            break;
                        case "admin":
                            Admin admin = new Admin(
                                insertedUserId,
                                name,
                                telephone,
                                email,
                                role,
                                birthday,
                                picture,
                                SalaryDecA,
                                workType,
                                workingHours
                            );
                            if (dbClass.InsertAdmin(admin))
                            {
                                MessageBox.Show("New admin added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearFields();
                            }
                            else
                            {
                                MessageBox.Show("Failed to add admin role", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            break;
                        case "student":
                            Student student = new Student(
                                insertedUserId,
                                name,
                                telephone,
                                email,
                                role,
                                birthday,
                                picture,
                                currentSubject1,
                                currentSubject2,
                                previousSubject1,
                                previousSubject2
                            );
                            if (dbClass.InsertStudent(student))
                            {
                                MessageBox.Show("New student added", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                ClearFields();
                            }
                            else
                            {
                                MessageBox.Show("Failed to add student role", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            break;
                        default:
                            MessageBox.Show("Please select a role", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                    showTable();
                }
                else
                {
                    MessageBox.Show("Failed to add user data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to validate phone number format
        private bool IsValidPhoneNumber(string phoneNumber)
        {
            return phoneNumber.Length == 10;
        }

        // Method to validate email format
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            int atIndex = email.IndexOf('@');
            if (atIndex == -1 || atIndex == 0 || atIndex == email.Length - 1)
                return false;

            string[] parts = email.Split('@');
            if (parts.Length != 2)
                return false;

            string domain = parts[1];
            int dotIndex = domain.IndexOf('.');
            if (dotIndex == -1 || dotIndex == 0 || dotIndex == domain.Length - 1)
                return false;

            return true;
        }

        // Method to get the text of the selected radio button in a group box
        private string GetSelectedRadioButtonText(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton radioButton && radioButton.Checked)
                {
                    return radioButton.Text;
                }
            }
            return "";
        }

        // Method to get the selected role from the ComboBox
        private string GetSelectedRole()
        {
            return comboBoxRole.SelectedItem?.ToString();
        }

        // Event handler for the Clear button click
        private void button_clear_Click_1(object sender, EventArgs e)
        {
            ClearFields();
        }

        // Event handler for the Upload button click
        private void button_upload_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pictureProfile.Image = new Bitmap(openFileDialog.FileName);
            }
        }

        // Method to clear all input fields and radio button selections
        private void ClearFields()
        {
            textBox_Name.Text = "";
            textBox_Email.Text = "";
            dateofbirth.Value = DateTime.Now;
            textBox_Phone.Text = "";
            textBox_Subject1.Text = "";
            textBox_Subject2.Text = "";
            textBox_CSubject1.Text = "";
            textBox_CSubject2.Text = "";
            textBox_SalaryA.Text = "";
            textBox_SalaryT.Text = "";
            textBox_PreSubject1.Text = "";
            textBox_PreSubject2.Text = "";
            pictureProfile.Image = null;

            // Clear radio button selections
            ClearRadioButtons(groupBoxWork);
            ClearRadioButtons(groupBoxHour);
        }

        // Method to clear radio button selections within a group box
        private void ClearRadioButtons(GroupBox groupBox)
        {
            foreach (Control control in groupBox.Controls)
            {
                if (control is RadioButton radioButton)
                {
                    radioButton.Checked = false;
                }
            }
        }

        // Method to verify if all required fields are filled
        private bool verify()
        {
            switch (GetSelectedRole())
            {
                case "teacher":
                    return !string.IsNullOrWhiteSpace(textBox_Name.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Email.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Phone.Text)

                        && !string.IsNullOrWhiteSpace(textBox_SalaryT.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Subject1.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Subject2.Text)
                        && pictureProfile.Image != null;
                case "admin":
                    return !string.IsNullOrWhiteSpace(textBox_Name.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Email.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Phone.Text)

                        && !string.IsNullOrWhiteSpace(textBox_SalaryA.Text)
                        && (ParttimeButton.Checked || FulltimeButton.Checked)
                        && (Morning.Checked || Afternoon.Checked || Night.Checked)
                        && pictureProfile.Image != null;
                case "student":
                    return !string.IsNullOrWhiteSpace(textBox_Name.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Email.Text)
                        && !string.IsNullOrWhiteSpace(textBox_Phone.Text)

                        && !string.IsNullOrWhiteSpace(textBox_CSubject1.Text)
                        && !string.IsNullOrWhiteSpace(textBox_CSubject2.Text)
                        && !string.IsNullOrWhiteSpace(textBox_PreSubject1.Text)
                        && !string.IsNullOrWhiteSpace(textBox_PreSubject2.Text)
                        && pictureProfile.Image != null;
                default:
                    return false; // Handle other roles or no role selected
            }
        }

        // To display table and refresh different table type
        private void showTable()
        {
            switch (selectedTableType)
            {
                case "teacher":
                    DataGridView.DataSource = dbClass.GetTeacherList();
                    break;
                case "admin":
                    DataGridView.DataSource = dbClass.GetAdminList();
                    break;
                case "student":
                    DataGridView.DataSource = dbClass.GetStudentList();
                    break;
                default:
                    DataGridView.DataSource = dbClass.GetUserList();
                    DataGridViewImageColumn column = (DataGridViewImageColumn)DataGridView.Columns["Picture"];
                    column.ImageLayout = DataGridViewImageCellLayout.Zoom;
                    break;
            }
        }

        // Event handler for the role selection ComboBox index change
        private void comboBoxRole_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Hide all group boxes first
            groupBoxTeacher.Visible = false;
            groupBoxAdmin.Visible = false;
            groupBoxStudent.Visible = false;

            // Show the group box corresponding to the selected role
            switch (comboBoxRole.SelectedItem?.ToString())
            {
                case "teacher":
                    groupBoxTeacher.Visible = true;
                    break;
                case "admin":
                    groupBoxAdmin.Visible = true;
                    break;
                case "student":
                    groupBoxStudent.Visible = true;
                    break;
                default:
                    break;
            }
        }

        // Event handler for the table type ComboBox index change
        private void comboBoxTableType_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Update the selected table type when the user selects a different table type
            selectedTableType = comboBoxTableType.SelectedItem.ToString();
            // Refresh the DataGridView with the data from the newly selected table
            showTable();
        }

        private void DataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureProfile_Click(object sender, EventArgs e)
        {

        }

        private void groupBoxStudent_Enter(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Morning_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBoxAdmin_Enter(object sender, EventArgs e)
        {

        }


        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


        private void Afternoon_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void FulltimeButton_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Night_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ParttimeButton_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}